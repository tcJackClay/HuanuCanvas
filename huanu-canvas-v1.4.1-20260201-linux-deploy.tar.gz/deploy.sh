#!/bin/bash
# HuanuCanvas Linux 一键部署脚本
# 版本: v1.4.1-20260201
# 用途: 解压后直接部署到 Linux 服务器

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 版本信息
VERSION="v1.4.1-20260201"
BUILD_DATE=$(date +%Y-%m-%d)

# 日志函数
log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# 检查 root 权限
check_root() {
    if [[ $EUID -ne 0 ]]; then
        log_warning "建议使用 root 权限运行: sudo $0"
    fi
}

# 检查 Docker
check_docker() {
    log_info "检查 Docker 环境..."
    
    if ! command -v docker &> /dev/null; then
        log_error "Docker 未安装，请先安装 Docker"
        echo "安装命令: curl -fsSL https://get.docker.com -o get-docker.sh && sh get-docker.sh"
        exit 1
    fi
    
    if ! command -v docker-compose &> /dev/null && ! docker compose version &> /dev/null; then
        log_error "Docker Compose 未安装，请先安装 Docker Compose"
        exit 1
    fi
    
    if ! docker info &> /dev/null; then
        log_error "Docker 服务未运行，请启动 Docker 服务"
        exit 1
    fi
    
    log_success "Docker 环境检查通过"
}

# 检查 Node.js
check_nodejs() {
    log_info "检查 Node.js 环境..."
    NODE_VERSION=$(node --version 2>/dev/null || echo "未安装")
    if [[ ! $NODE_VERSION =~ ^v2[1-9]\. ]]; then
        log_warning "Node.js 21.x 未安装，将使用 Docker 构建后端"
    else
        log_success "Node.js 版本: $NODE_VERSION"
    fi
}

# 安装依赖
install_dependencies() {
    log_info "安装项目依赖..."
    
    # 检查是否需要安装
    if [[ -d "node_modules" ]]; then
        log_info "依赖已存在，跳过安装"
        return 0
    fi
    
    # 检查 Node.js
    if command -v node &> /dev/null; then
        NODE_VERSION=$(node --version)
        if [[ $NODE_VERSION =~ ^v2[1-9]\. ]]; then
            log_info "使用 Node.js 安装依赖..."
            npm ci --only=production || npm install --only=production
        fi
    fi
    
    log_success "依赖安装完成"
}

# 构建应用
build_application() {
    log_info "构建应用..."
    
    # 前端已预构建，解压后即可使用
    if [[ -d "dist" ]]; then
        log_success "前端构建产物已存在"
    else
        log_error "前端构建产物不存在: dist/"
        exit 1
    fi
    
    # 检查后端
    if [[ ! -d "src/backend" ]]; then
        log_error "后端源代码不存在: src/backend"
        exit 1
    fi
    
    log_success "应用构建检查完成"
}

# 配置环境变量
configure_environment() {
    log_info "配置环境变量..."
    
    if [[ -f ".env" ]]; then
        log_info "环境变量已配置"
        return 0
    fi
    
    if [[ -f ".env.example" ]]; then
        cp .env.example .env
        log_warning "已创建 .env 文件，请编辑配置 GEMINI_API_KEY 等参数"
    fi
    
    if [[ -f "deployment/.env.example" ]]; then
        cp deployment/.env.example deployment/.env
        log_warning "已创建 deployment/.env 文件"
    fi
}

# 部署 Docker 服务
deploy_docker() {
    log_info "部署 Docker 服务..."
    
    cd deployment
    
    # 清理旧容器
    log_info "清理旧容器..."
    docker-compose down --remove-orphans 2>/dev/null || true
    
    # 构建并启动服务
    log_info "构建并启动服务..."
    docker-compose up -d --build
    
    cd ..
    
    log_success "Docker 服务部署完成"
}

# 显示服务状态
show_status() {
    echo ""
    echo "=========================================="
    echo "  HuanuCanvas 部署完成 - $VERSION"
    echo "=========================================="
    echo ""
    echo "服务访问地址:"
    echo "  - 前端应用: http://localhost"
    echo "  - 后端API:  http://localhost:8765"
    echo "  - 健康检查: http://localhost/health"
    echo ""
    echo "监控服务 (如已启用):"
    echo "  - Grafana:   http://localhost:3000"
    echo "  - Prometheus: http://localhost:9090"
    echo ""
    echo "管理命令:"
    echo "  - 查看日志: ./manage.sh logs"
    echo "  - 重启服务: ./manage.sh restart"
    echo "  - 停止服务: ./manage.sh stop"
    echo "  - 健康检查: ./health.sh"
    echo ""
    echo "=========================================="
}

# 主函数
main() {
    echo "=========================================="
    echo "  HuanuCanvas Linux 一键部署脚本"
    echo "  版本: $VERSION"
    echo "  构建日期: $BUILD_DATE"
    echo "=========================================="
    echo ""
    
    # 检查环境
    check_root
    check_docker
    check_nodejs
    
    # 安装依赖
    install_dependencies
    
    # 构建应用
    build_application
    
    # 配置环境变量
    configure_environment
    
    # 部署 Docker
    deploy_docker
    
    # 显示状态
    show_status
    
    log_success "部署完成！"
}

# 执行主函数
main "$@"
