#!/bin/bash
# HuanuCanvas 健康检查脚本
# 版本: v1.4.1-20260201
# 用途: 检查 Docker 服务健康状态

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

VERSION="v1.4.1-20260201"

# 日志函数
log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[PASS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[FAIL]${NC} $1"; }

# 检查参数
VERBOSE=false
JSON_OUTPUT=false

while [[ $# -gt 0 ]]; do
    case $1 in
        --verbose|-v)
            VERBOSE=true
            shift
            ;;
        --json|-j)
            JSON_OUTPUT=true
            shift
            ;;
        --help|-h)
            echo "用法: $0 [选项]"
            echo ""
            echo "选项:"
            echo "  --verbose, -v  显示详细信息"
            echo "  --json, -j     JSON 格式输出"
            echo "  --help, -h     显示帮助"
            exit 0
            ;;
        *)
            shift
            ;;
    esac
done

# 服务配置
SERVICES=(
    "frontend:80:HTTP"
    "backend:8765:TCP"
    "redis:6379:TCP"
    "postgres:5432:TCP"
)

# 检查单个服务
check_service() {
    local name=$1
    local port=$2
    local type=$3
    
    if [[ "$type" == "HTTP" ]]; then
        if curl -sf "http://localhost:$port/health" > /dev/null 2>&1; then
            return 0
        elif curl -sf "http://localhost:$port" > /dev/null 2>&1; then
            return 0
        else
            return 1
        fi
    else
        if timeout 2 bash -c "echo > /dev/tcp/localhost/$port" 2>/dev/null; then
            return 0
        else
            return 1
        fi
    fi
}

# 收集 Docker 容器状态
get_container_status() {
    local container_name=$1
    docker ps --format '{{.Names}}' | grep -q "$container_name"
    if [[ $? -eq 0 ]]; then
        local status=$(docker ps --filter "name=$container_name" --format '{{.Status}}' | head -1)
        echo "$status"
    else
        echo "not running"
    fi
}

# 检查 Docker 卷
check_volumes() {
    log_info "检查 Docker 卷..."
    local volumes=($(docker volume ls --format '{{.Name}}' | grep "huanu" | head -10))
    
    if [[ ${#volumes[@]} -gt 0 ]]; then
        log_success "找到 ${#volumes[@]} 个 HuanuCanvas 数据卷"
        if $VERBOSE; then
            for vol in "${volumes[@]}"; do
                echo "  - $vol"
            done
        fi
    else
        log_warning "未找到 HuanuCanvas 数据卷"
    fi
}

# 检查系统资源
check_system_resources() {
    if $VERBOSE; then
        log_info "系统资源使用情况:"
        echo "  CPU: $(top -bn1 | grep "Cpu(s)" | awk '{print $2}')%"
        echo "  内存: $(free -h | grep Mem | awk '{print $3 "/" $2}')"
        echo "  磁盘: $(df -h / | tail -1 | awk '{print $5 " used"}')"
    fi
}

# 整体健康检查
run_health_check() {
    local total=0
    local passed=0
    local failed=0
    
    echo "=========================================="
    echo "  HuanuCanvas 健康检查"
    echo "  版本: $VERSION"
    echo "  时间: $(date '+%Y-%m-%d %H:%M:%S')"
    echo "=========================================="
    echo ""
    
    log_info "检查服务状态..."
    echo ""
    
    for service in "${SERVICES[@]}"; do
        IFS=':' read -r name port type <<< "$service"
        ((total++))
        
        if check_service "$name" "$port" "$type"; then
            ((passed++))
            if $JSON_OUTPUT; then
                echo "{\"service\":\"$name\",\"port\":$port,\"status\":\"healthy\"}"
            else
                log_success "$name (端口 $port)"
            fi
        else
            ((failed++))
            if $JSON_OUTPUT; then
                echo "{\"service\":\"$name\",\"port\":$port,\"status\":\"unhealthy\"}"
            else
                log_error "$name (端口 $port)"
            fi
        fi
    done
    
    echo ""
    log_info "Docker 容器状态:"
    echo ""
    
    local containers=("frontend" "backend" "redis" "postgres")
    for container in "${containers[@]}"; do
        local status=$(get_container_status "huanu-$container")
        if [[ "$status" != "not running" ]]; then
            if $JSON_OUTPUT; then
                echo "{\"container\":\"huanu-$container\",\"status\":\"$status\"}"
            else
                echo "  - huanu-$container: $status"
            fi
        fi
    done
    
    # 检查数据卷
    echo ""
    check_volumes
    
    # 显示资源使用情况
    if $VERBOSE; then
        echo ""
        check_system_resources
    fi
    
    echo ""
    echo "=========================================="
    echo "  检查结果: $passed/$total 通过"
    
    if [[ $failed -gt 0 ]]; then
        echo "  状态: ${RED}存在问题${NC}"
        echo "=========================================="
        if ! $JSON_OUTPUT; then
            echo ""
            log_warning "问题排查建议:"
            echo "  1. 查看日志: ./manage.sh logs"
            echo "  2. 重启服务: ./manage.sh restart"
            echo "  3. 检查配置: 检查 .env 文件中的配置"
        fi
        exit 1
    else
        echo "  状态: ${GREEN}全部正常${NC}"
        echo "=========================================="
        exit 0
    fi
}

# 执行健康检查
run_health_check