#!/bin/bash
# HuanuCanvas 服务管理脚本
# 版本: v1.4.1-20260201
# 用途: Docker 服务管理

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

VERSION="v1.4.1-20260201"

# 日志函数
log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# 检查 Docker Compose
check_docker_compose() {
    if command -v docker-compose &> /dev/null; then
        COMPOSE_CMD="docker-compose"
    elif docker compose version &> /dev/null; then
        COMPOSE_CMD="docker compose"
    else
        log_error "Docker Compose 未安装"
        exit 1
    fi
}

# 启动服务
start_services() {
    check_docker_compose
    log_info "启动 HuanuCanvas 服务..."
    cd deployment
    $COMPOSE_CMD up -d
    cd ..
    log_success "服务启动完成"
}

# 停止服务
stop_services() {
    check_docker_compose
    log_info "停止 HuanuCanvas 服务..."
    cd deployment
    $COMPOSE_CMD down
    cd ..
    log_success "服务已停止"
}

# 重启服务
restart_services() {
    check_docker_compose
    log_info "重启 HuanuCanvas 服务..."
    cd deployment
    $COMPOSE_CMD restart
    cd ..
    log_success "服务重启完成"
}

# 查看日志
view_logs() {
    check_docker_compose
    local service="${1:-}"
    
    if [[ -n "$service" ]]; then
        log_info "查看 $service 服务日志 (按 Ctrl+C 退出)..."
        cd deployment
        $COMPOSE_CMD logs -f "$service"
        cd ..
    else
        log_info "查看所有服务日志 (按 Ctrl+C 退出)..."
        cd deployment
        $COMPOSE_CMD logs -f
        cd ..
    fi
}

# 检查服务状态
check_status() {
    check_docker_compose
    log_info "检查服务状态..."
    echo ""
    cd deployment
    $COMPOSE_CMD ps
    cd ..
}

# 构建并重新部署
rebuild_services() {
    check_docker_compose
    log_info "重新构建并部署服务..."
    cd deployment
    $COMPOSE_CMD up -d --build
    cd ..
    log_success "构建部署完成"
}

# 清理资源
cleanup_resources() {
    check_docker_compose
    log_info "清理 Docker 资源..."
    cd deployment
    $COMPOSE_CMD down --volumes --remove-orphans
    cd ..
    log_warning "数据卷已删除，所有数据将被清除"
}

# 显示帮助
show_help() {
    echo "=========================================="
    echo "  HuanuCanvas 服务管理脚本"
    echo "  版本: $VERSION"
    echo "=========================================="
    echo ""
    echo "用法: $0 <命令> [服务名]"
    echo ""
    echo "命令:"
    echo "  start       启动所有服务"
    echo "  stop        停止所有服务"
    echo "  restart     重启所有服务"
    echo "  logs        查看日志 (可选: 服务名)"
    echo "  status      检查服务状态"
    echo "  rebuild     重新构建并部署"
    echo "  cleanup     清理所有资源 (慎用!)"
    echo "  help        显示帮助"
    echo ""
    echo "示例:"
    echo "  $0 start          # 启动服务"
    echo "  $0 logs backend   # 查看后端日志"
    echo "  $0 restart        # 重启服务"
    echo "  $0 status         # 检查状态"
    echo ""
}

# 主函数
main() {
    case "${1:-help}" in
        "start")
            start_services
            ;;
        "stop")
            stop_services
            ;;
        "restart")
            restart_services
            ;;
        "logs")
            view_logs "${2:-}"
            ;;
        "status")
            check_status
            ;;
        "rebuild")
            rebuild_services
            ;;
        "cleanup")
            cleanup_resources
            ;;
        "help"|"-h"|"--help")
            show_help
            ;;
        *)
            log_error "未知命令: $1"
            show_help
            exit 1
            ;;
    esac
}

# 执行主函数
main "$@"